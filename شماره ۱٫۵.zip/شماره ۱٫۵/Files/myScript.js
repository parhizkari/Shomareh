
window.location.href='#';


//=================  TRANSFORM NUMBERS TO PERSIAN  ==================



function toFa(textContainingEnglishNumbers){
	return textContainingEnglishNumbers.toString()
		.replace(/0/g,'۰').replace(/1/g,'۱').replace(/2/g,'۲').replace(/3/g,'۳').replace(/4/g,'۴').replace(/5/g,'۵')
		.replace(/6/g,'۶').replace(/7/g,'۷').replace(/8/g,'۸').replace(/9/g,'۹').replace(/\./g,'/');
}



//=============  FIND THE PRESENT DATE IN THE PERSIAN CALENDAR  ==============//



function gregorian_to_jalali(gy,gm,gd){
	g_d_m=[0,31,59,90,120,151,181,212,243,273,304,334];
	jy=(gy<=1600)?0:979;
	gy-=(gy<=1600)?621:1600;
	gy2=(gm>2)?(gy+1):gy;
	days=(365*gy) +(parseInt((gy2+3)/4)) -(parseInt((gy2+99)/100)) +(parseInt((gy2+399)/400)) -80 +gd +g_d_m[gm-1];
	jy+=33*(parseInt(days/12053)); 
	days%=12053;
	jy+=4*(parseInt(days/1461));
	days%=1461;
	jy+=parseInt((days-1)/365);
 	if(days > 365)days=(days-1)%365;
	jm=(days < 186)?1+parseInt(days/31):7+parseInt((days-186)/30);
	jd=1+((days < 186)?(days%31):((days-186)%30));
	return [jy,jm,jd];
};
var persianMonth=["","فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"];
var morningAfternnon;
function persianDateTime(){
	d=new Date();
	g_y=d.getFullYear();
	g_m=d.getMonth()+1;
	g_d=d.getDate();
	shamsi=gregorian_to_jalali(g_y,g_m,g_d);
	H=d.getHours();
	//H=(H<10)?"0"+H:H;
	morningAfternnon= 
		(H==12)  ? "ظهر" : (
			(H!=0) ? (
				(H<12) ? "صبح" : (
					(H>=20) ? "شب" :  "بعد از ظهر"
				)
			)
			: "نیمه‌شب"
		);
	i = d.getMinutes();
	i = (i<10) ? "0"+i : i;
	var shortDate=shamsi[0]+"٫"+shamsi[1]+"٫"+shamsi[2]+" - "+H+":"+i;
	
	shortDate=toFa(shortDate.toString());
	
	return shortDate;
}; // now you can use the present date by calling the function  persianDateTime()




//=============  CLOSE POPUP BY PRESSING 'ESC' OR CLICKING OUTSIDE THE POPUP  ==============



document.addEventListener("keydown", function(e){
	if (e.keyCode == 27) { window.location.href='#'; }	// checks if Esc key is pressed
});
document.onclick = function(e){
	//check if the dark backgrounds of the popups are clicked ...
	if(e.target.id == 'popupAbout'){
		window.location.href='#';
	}
}



//=================  ADD TABLES  ==================//



var myJSONData=[],			// the main variable (JSON DATABASE) which contains the whole data
	keyword="";					// the searched keyword

function refresh(){
	if(document.getElementById("dataTable")){
		if(confirm('با ادامه‌ی این کار، اطلاعات فعلی در صورتی که قبلاً ذخیره نشده باشند از دست می‌روند، آیا با این حال ادامه می‌دهید؟')){
			/*var	header=document.getElementById("headerTable"),
				table=document.getElementById("dataTable");
			header.parentNode.removeChild(header);
			table.parentNode.removeChild(table);*/
			document.getElementById("container").innerHTML="";
			myJSONData=[];
		}
	}
}

function addRow() {
	var table, table_len;
	if(document.getElementById("dataTable")){
		table=document.getElementById("dataTable");
		table_len=(table.rows.length);
		for(var i=0; i<table_len; i++){
			if(document.getElementById("save"+i)){	// so that there exists at least one unsaved row of data
				alert("لطفاً ابتدا ردیف ذخیره نشده را ذخیره بفرمایید!");
				return false;
			}
		}
	}
	if(!document.getElementById("dataTable")){
		document.getElementById("container").innerHTML=
			'<table id="headerTable" align="center" cellspacing=0 cellpadding=0 border=0>' // required to only generate the "position:fixed" header, floating (fixed on screen) while onScroll
				+'<tr style="height:30px;">'
					+'<th style="width:5%; border:none;"></th>'
					+'<th style="width:12%; vertical-align:middle;">'
						+'<table style="display:inline-bock;" align="center" cellspacing=0 cellpadding=0 border=0>'
							+'<tr>'
								+'<th rowspan="2" style="border:none; background:none; color:snow; width:60%;" align="left">نام</th>'
								+'<td align="right" style="padding:0px; margin-bottom:-30px;">'
									+'<input class="myButton" onclick="sortNameAscending();" type="image" src="Files/images/sort_asc.png" alt="" title="مرتب کردن داده‌ها بر حسب «نام» به ترتیب حروف الفباء" align="center" width="10" height="10" style="position:relative; margin-bottom:-5px; margin-right:3px;">'
								+'</td>'
							+'</tr>'
							+'<tr><td align="right" style="padding:0px; margin-top:-30;">'
								+'<input class="myButton" onclick="sortNameDescending();" type="image" src="Files/images/sort_desc.png" alt="" title="مرتب کردن داده‌ها بر حسب «نام» به ترتیب عکس حروف الفباء" align="center" width="10" height="10" style="position:relative; margin-top:-15px; margin-right:3px;">'
							+'</td></tr>'
						+'</table>'
					+'</th>'
					+'<th style="width:10%; vertical-align:middle;">'
						+'<table style="display:inline-bock;" align="center" cellspacing=0 cellpadding=0 border=0>'
							+'<tr>'
								+'<th rowspan="2" style="border:none; background:none; color:snow; width:60%;" align="left">گروه</th>'
								+'<td align="right" style="padding:0px; margin-bottom:-30px;">'
									+'<input class="myButton" onclick="sortGroupAscending();" type="image" src="Files/images/sort_asc.png" alt="" title="مرتب کردن داده‌ها بر حسب «گروه» به ترتیب حروف الفباء" align="center" width="10" height="10" style="position:relative; margin-bottom:-5px; margin-right:3px;">'
								+'</td>'
							+'</tr>'
							+'<tr><td align="right" style="padding:0px; margin-top:-30;">'
								+'<input class="myButton" onclick="sortGroupDescending();" type="image" src="Files/images/sort_desc.png" alt="" title="مرتب کردن داده‌ها بر حسب «گروه» به ترتیب عکس حروف الفباء" align="center" width="10" height="10" style="position:relative; margin-top:-15px; margin-right:3px;">'
							+'</td></tr>'
						+'</table>'
					+'</th>'
					+'<th style="width:13%; color:snow;">تلفن ثابت</th>'
					+'<th style="width:13%; color:snow;">تلفن همراه</th>'
					+'<th style="width:25%; color:snow;">آدرس</th>'
					+'<th style="width:12%; color:snow;">توضیحات</th>'
				+'</tr>'
			+'</table>'
			+'<table id="dataTable" cellspacing=0 cellpadding=0 style="margin-top:80px; margin-right:5%;" border=0>'   						// main data table with its own common header
				+'<tr style="height:30px;">'		// an empty row hidden, works as vertical spacer
					+'<th style="width:5%; border:none; background:none;"></th>'
					+'<th style="width:12%; border:none; background:none;"></th>'
					+'<th style="width:10%; border:none; background:none;"></th>'
					+'<th style="width:13%; border:none; background:none;"></th>'
					+'<th style="width:13%; border:none; background:none;"></th>'
					+'<th style="width:25%; border:none; background:none;"></th>'
					+'<th style="width:12%; border:none; background:none;"></th>'
				+'</tr>'
				+'</tr>'
			+'</table><br><br>';
	}
	table=document.getElementById("dataTable");
	table_len=(table.rows.length);
	
	var row = table.insertRow(table_len).outerHTML=
		'<tr id="row'+table_len+'">'
			+'<td id="edit'+table_len+'">'
				+'<input id="save'+table_len+'" class="myButton" onclick="saveRow('+table_len+')" type="image" src="Files/images/ok.png" alt="" title="ذخیره" align="center" width="20" height="20" style="position:relative; margin-bottom:3px; margin-left:3px;">'
			+'</td>'
			+'<td contenteditable="true" id="Name'+table_len+'"></td>'
			+'<td contenteditable="true" id="Group'+table_len+'"></td>'
			+'<td contenteditable="true" id="Phone'+table_len+'"></td>'
			+'<td contenteditable="true" id="Mobile'+table_len+'"></td>'
			+'<td contenteditable="true" id="Address'+table_len+'"></td>'
			+'<td contenteditable="true" id="Description'+table_len+'"></td>'
		+'</tr>';
	
	setTimeout(function(){
		document.getElementById("Name"+table_len).focus();
	}, 500);
}

function saveRow(num){
	document.getElementById("Name"+num).innerHTML=document.getElementById("Name"+num).innerHTML.replace(/\<br\>/,"");
	document.getElementById("Name"+num).setAttribute("contenteditable", false);
	document.getElementById("Group"+num).innerHTML=document.getElementById("Group"+num).innerHTML.replace(/\<br\>/,"");
	document.getElementById("Group"+num).setAttribute("contenteditable", false);
	document.getElementById("Phone"+num).innerHTML=toFa(document.getElementById("Phone"+num).innerHTML);
	document.getElementById("Phone"+num).setAttribute("contenteditable", false);
	document.getElementById("Mobile"+num).innerHTML=toFa(document.getElementById("Mobile"+num).innerHTML);;
	document.getElementById("Mobile"+num).setAttribute("contenteditable", false);
	document.getElementById("Address"+num).setAttribute("contenteditable", false);
	document.getElementById("Description"+num).setAttribute("contenteditable", false);
	
	document.getElementById("edit"+num).innerHTML=
		'<input class="myButton" onclick="editRow('+num+')" type="image" src="Files/images/edit.png" alt="" title="ویرایش ردیف" align="center" width="20" height="20" style="position:relative; margin-bottom:3px; margin-left:3px;">'
		+'<input class="myButton" onclick="deleteRow('+num+')" type="image" src="Files/images/close.png" alt="" title="حذف ردیف" align="center" width="20" height="20" style="position:relative; margin-bottom:3px;">';
	
	myJSONData[num-1]={
			"Name":document.getElementById("Name"+num).innerHTML,
			"Group":document.getElementById("Group"+num).innerHTML,
			"Phone":document.getElementById("Phone"+num).innerHTML,
			"Mobile":document.getElementById("Mobile"+num).innerHTML,
			"Address":document.getElementById("Address"+num).innerHTML,
			"Description":document.getElementById("Description"+num).innerHTML
		};
	saveToCache();	// to save in cache the changes in the JSON dataset
	
	document.getElementById("search").focus();
}

function editRow(num){
	var table, table_len;
	if(document.getElementById("dataTable")){
		table=document.getElementById("dataTable");
		table_len=(table.rows.length);
		for(var i=0; i<table_len; i++){
			if(document.getElementById("save"+i)){	// so that there exists at least one unsaved row of data
				alert("لطفاً ابتدا ردیف ذخیره نشده را ذخیره بفرمایید!");
				return false;
			}
		}
	}
	
	document.getElementById("Name"+num).setAttribute("contenteditable", true);
	document.getElementById("Group"+num).setAttribute("contenteditable", true);
	document.getElementById("Phone"+num).setAttribute("contenteditable", true);
	document.getElementById("Mobile"+num).setAttribute("contenteditable", true);
	document.getElementById("Address"+num).setAttribute("contenteditable", true);
	document.getElementById("Description"+num).setAttribute("contenteditable", true);
	
	setTimeout(function(){
		document.getElementById("Name"+num).focus();
	}, 500);
	
	document.getElementById("edit"+num).innerHTML=
		'<input id="save'+num+'" class="myButton" onclick="saveRow('+num+')" type="image" src="Files/images/ok.png" alt="" title="ذخیره" align="center" width="20" height="20" style="position:relative; margin-bottom:3px; margin-left:3px;">';
}

function deleteRow(num){
	if(confirm('با ادامه‌ی این کار، رکورد ثبت شده برای «'+document.getElementById("Name"+num).innerHTML+'» پاک خواهد شد، آیا با این حال ادامه می‌دهید؟')){
		document.getElementById("row"+num).outerHTML="";		// this deletes the selected row in the table
	} else {
		return false;
	}
	
	myJSONData.splice((num-1), 1);					// deletes the row information from the JSON dataset
	
	saveToCache();								// to save in cache the changes in the JSON dataset
	
	var	//header=document.getElementById("headerTable"),
		table=document.getElementById("dataTable"),
		l=(table.rows.length);
	
	if(l==1){
		//header.parentNode.removeChild(header);
		//table.parentNode.removeChild(table);
		document.getElementById("container").innerHTML="";
		return false;
	}
	
	// Now let change the id of all the following rows to the end of table ...
	for(var i=num+1 ; i<=l ; i++){
		document.getElementById("row"+i).setAttribute("id","row"+(i-1));
		document.getElementById("Name"+i).setAttribute("id","Name"+(i-1));
		document.getElementById("Group"+i).setAttribute("id","Group"+(i-1));
		document.getElementById("Phone"+i).setAttribute("id","Phone"+(i-1));
		document.getElementById("Mobile"+i).setAttribute("id","Mobile"+(i-1));
		document.getElementById("Address"+i).setAttribute("id","Address"+(i-1));
		document.getElementById("Description"+i).setAttribute("id","Description"+(i-1));
		document.getElementById("edit"+i).innerHTML=
			'<input class="myButton" onclick="editRow('+(i-1)+')" type="image" src="Files/images/edit.png" alt="" title="ویرایش ردیف" align="center" width="20" height="20" style="position:relative; margin-bottom:3px; margin-left:3px;">'
			+'<input class="myButton" onclick="deleteRow('+(i-1)+')" type="image" src="Files/images/close.png" alt="" title="حذف ردیف" align="center" width="20" height="20" style="position:relative; margin-bottom:3px;">';
		document.getElementById("edit"+i).setAttribute("id","edit"+(i-1));
	}
	
	document.getElementById("search").focus();
}

function fillTheTable(){
	// first remove the previous table if it existed ...
	/*if(document.getElementById("headerTable")){
		var	header=document.getElementById("headerTable"),
			table=document.getElementById("dataTable");
		header.parentNode.removeChild(header);
		table.parentNode.removeChild(table);
	}*/
	document.getElementById('container').innerHTML="";
	
	
	if(myJSONData.length){
		var rows="";
		for(var i=0, l=myJSONData.length ; i<l ; i++){
			rows+=
				'<tr id="row'+(i+1)+'">'
					+'<td id="edit'+(i+1)+'">'
						+'<input class="myButton" onclick="editRow('+(i+1)+')" type="image" src="Files/images/edit.png" alt="" title="ویرایش ردیف" align="center" width="20" height="20" style="position:relative; margin-bottom:3px; margin-left:3px;">'
						+'<input class="myButton" onclick="deleteRow('+(i+1)+')" type="image" src="Files/images/close.png" alt="" title="حذف ردیف" align="center" width="20" height="20" style="position:relative; margin-bottom:3px;">'
					+'</td>'
					+'<td id="Name'+(i+1)+'">'+myJSONData[i].Name+'</td>'
					+'<td id="Group'+(i+1)+'">'+myJSONData[i].Group+'</td>'
					+'<td id="Phone'+(i+1)+'">'+myJSONData[i].Phone+'</td>'
					+'<td id="Mobile'+(i+1)+'">'+myJSONData[i].Mobile+'</td>'
					+'<td id="Address'+(i+1)+'">'+myJSONData[i].Address+'</td>'
					+'<td id="Description'+(i+1)+'">'+myJSONData[i].Description+'</td>'
				+'</tr>';
		}
		document.getElementById('container').innerHTML=
			'<table id="headerTable" align="center" cellspacing=0 cellpadding=0 border=0>' // required to only generate the "position:fixed" header, floating (fixed on screen) while onScroll
				+'<tr style="height:30px;">'
					+'<th style="width:5%; border:none;"></th>'
					+'<th style="width:12%; vertical-align:middle;">'
						+'<table style="display:inline-bock;" align="center" cellspacing=0 cellpadding=0 border=0>'
							+'<tr>'
								+'<th rowspan="2" style="border:none; background:none; color:snow; width:60%;" align="left">نام</th>'
								+'<td align="right" style="padding:0px; margin-bottom:-30px;">'
									+'<input class="myButton" onclick="sortNameAscending();" type="image" src="Files/images/sort_asc.png" alt="" title="مرتب کردن داده‌ها بر حسب «نام» به ترتیب حروف الفباء" align="center" width="10" height="10" style="position:relative; margin-bottom:-5px; margin-right:3px;">'
								+'</td>'
							+'</tr>'
							+'<tr><td align="right" style="padding:0px; margin-top:-30;">'
								+'<input class="myButton" onclick="sortNameDescending();" type="image" src="Files/images/sort_desc.png" alt="" title="مرتب کردن داده‌ها بر حسب «نام» به ترتیب عکس حروف الفباء" align="center" width="10" height="10" style="position:relative; margin-top:-15px; margin-right:3px;">'
							+'</td></tr>'
						+'</table>'
					+'</th>'
					+'<th style="width:10%; vertical-align:middle;">'
						+'<table style="display:inline-bock;" align="center" cellspacing=0 cellpadding=0 border=0>'
							+'<tr>'
								+'<th rowspan="2" style="border:none; background:none; color:snow; width:60%;" align="left">گروه</th>'
								+'<td align="right" style="padding:0px; margin-bottom:-30px;">'
									+'<input class="myButton" onclick="sortGroupAscending();" type="image" src="Files/images/sort_asc.png" alt="" title="مرتب کردن داده‌ها بر حسب «گروه» به ترتیب حروف الفباء" align="center" width="10" height="10" style="position:relative; margin-bottom:-5px; margin-right:3px;">'
								+'</td>'
							+'</tr>'
							+'<tr><td align="right" style="padding:0px; margin-top:-30;">'
								+'<input class="myButton" onclick="sortGroupDescending();" type="image" src="Files/images/sort_desc.png" alt="" title="مرتب کردن داده‌ها بر حسب «گروه» به ترتیب عکس حروف الفباء" align="center" width="10" height="10" style="position:relative; margin-top:-15px; margin-right:3px;">'
							+'</td></tr>'
						+'</table>'
					+'</th>'
					+'<th style="width:13%; color:snow;">تلفن ثابت</th>'
					+'<th style="width:13%; color:snow;">تلفن همراه</th>'
					+'<th style="width:25%; color:snow;">آدرس</th>'
					+'<th style="width:12%; color:snow;">توضیحات</th>'
				+'</tr>'
			+'</table>'
			+'<table id="dataTable" cellspacing=0 cellpadding=0 style="margin-top:80px; margin-right:5%;" border=0>'   						// main data table with its own common header
				+'<tr style="height:30px;">'		// an empty row hidden, works as vertical spacer
					+'<th style="width:5%; border:none; background:none;"></th>'
					+'<th style="width:12%; border:none; background:none;"></th>'
					+'<th style="width:10%; border:none; background:none;"></th>'
					+'<th style="width:13%; border:none; background:none;"></th>'
					+'<th style="width:13%; border:none; background:none;"></th>'
					+'<th style="width:25%; border:none; background:none;"></th>'
					+'<th style="width:12%; border:none; background:none;"></th>'
				+'</tr>'
				+rows
			+'</table><br><br>';
	}
	
	document.getElementById("search").focus();
}


function sortNameAscending(){
	myJSONData.sort(function(a, b){return a["Name"].localeCompare(b["Name"])});
	saveToCache();	// to save in cache the changes in the JSON dataset
	fillTheTable();
	document.getElementById("search").value=keyword;
}
function sortNameDescending(){
	myJSONData.sort(function(b, a){return a["Name"].localeCompare(b["Name"])});
	saveToCache();	// to save in cache the changes in the JSON dataset
	fillTheTable();
	document.getElementById("search").value=keyword;
}


function sortGroupAscending(){
	myJSONData.sort(function(a, b){return a["Group"].localeCompare(b["Group"])});
	saveToCache();	// to save in cache the changes in the JSON dataset
	fillTheTable();
	document.getElementById("search").value=keyword;
}
function sortGroupDescending(){
	myJSONData.sort(function(b, a){return a["Group"].localeCompare(b["Group"])});
	saveToCache();	// to save in cache the changes in the JSON dataset
	fillTheTable();
	document.getElementById("search").value=keyword;
}



//=============  SEARCH FUNCTIONALITY  ==============



function search(){
	keyword=document.getElementById("search").value;
	keywordFa=toFa(keyword);
	if(myJSONData.length){
		for(var i=0, l=myJSONData.length ; i<l ; i++){
			document.getElementById('row'+(i+1)).style.display="";
			
			if(myJSONData[i].Name.indexOf(keyword)==-1 &&
			   myJSONData[i].Group.indexOf(keyword)==-1 &&
			   myJSONData[i].Phone.indexOf(keyword)==-1 &&
			   myJSONData[i].Mobile.indexOf(keyword)==-1 &&
			   myJSONData[i].Address.indexOf(keyword)==-1 &&
			   myJSONData[i].Description.indexOf(keyword)==-1){
					document.getElementById('row'+(i+1)).style.display="none";
			}
		}
		document.getElementById('search').focus();
		document.getElementById("search").value=keyword;
	}else{alert("هنوز داده‌ای وارد نشده است که جستجو انجام پذیرد!");}
}



//=============  USE localStorage OF HTML5 TO AUTOMATE SAVING OF DATA IN CACHE ==============//



function saveToCache(){
	window.localStorage["savedInCahe"] = JSON.stringify(myJSONData);	// stores the data to the browser's cache
	document.getElementById('save-log').style.display = 'inline-block';
	setTimeout(function() {
		document.getElementById('save-log').style.display = 'none';	// the save-log will last for 1 second (1000 ms) before it will become display-none ...
	}, 1000);
}




//=============  USE localStorage OF HTML5 TO RELOAD DATA FROM CACHE AT START  ==============//



if (window.localStorage["savedInCahe"]) {
	myJSONData = JSON.parse(window.localStorage["savedInCahe"]);	//retrieves the data from the browser's cache even after the browser/tab is reopened
	fillTheTable();
}


//====================  OPEN A NEW FILE  =====================



var openFile=document.getElementById("Openfile");

function openFunction(){
	if(document.getElementById("dataTable")){
		if(!confirm('با باز کردن فایل جدید، اطلاعات فعلی در صورتی که قبلاً ذخیره نشده باشند از دست می‌روند، آیا با این حال ادامه می‌دهید؟')){
			return false;
		}
	}
	openFile.click();	// this opens the file browser dialog for selecting a file to open
	return;
};

openFile.addEventListener('change', function() {
	var fileToLoad=openFile.files[0];			// the selected file itself as an object?
	var fileToLoadAddress=openFile.value;		// the relative or absolute address of the selected file
	
	document.getElementById("bookName").innerHTML=fileToLoadAddress.split('\\').pop()
		.replace(/(.txt)/,"").replace(/\./g,":");	// this writes the name of the file opened in the header at the top
	
	if(fileToLoad){
		var reader=new FileReader();
		reader.readAsText(fileToLoad, "UTF-8");
		reader.onload=function(event){
			myJSONData = JSON.parse(event.target.result);
			saveToCache();	// to save in cache the changes in the JSON dataset
			fillTheTable();
		}
		reader.onerror=function(event){
			alert("بارگذاری فایل انتخاب شده ناموفق بود!");
		}
	}
});



// -----------------------------------------------------------------------------
// Drag&Drop text file to open the file's content there
// got the inspiration from "http://devjs.eu/en/drag-multiple-text-files-to-your-web-application-with-html5-and-javascript/"


document.getElementById("container").addEventListener('dragover', dragOver);
document.getElementById("container").addEventListener('dragend', dragEnd);
document.getElementById("container").addEventListener('drop', readText, false);

function dragOver(e){
	e.stopPropagation(); // for some browsers stop redirecting
	e.preventDefault();
	//e.dataTransfer.effectAllowed = "move";		// when the curser changed, the file can be dropped!
	return false;
}
function dragEnd(e){
	e.stopPropagation(); // for some browsers stop redirecting
	e.preventDefault();
	return false;
}
function readText(e){
	e.stopPropagation(); // for some browsers stop redirecting
	e.preventDefault();
	
	var fileData, reader, file=e.dataTransfer.files[0];
	if (!file) {return false;}
	
	if(document.getElementById("dataTable")){
		if(!confirm('با باز کردن فایل جدید، اطلاعات فعلی در صورتی که قبلاً ذخیره نشده باشند از دست می‌روند، آیا با این حال ادامه می‌دهید؟')){
			return false;
		}
	}
    
    //to read the content of the file
    reader=new FileReader();
	reader.readAsText(file, "UTF-8");
	reader.onload=function(event){
		myJSONData = JSON.parse(event.target.result);
		saveToCache();	// to save in cache the changes in the JSON dataset
		fillTheTable();
	}
	reader.onerror=function(event){
		alert("بارگذاری فایل انتخاب شده ناموفق بود!");
		return false;
	}
	
	
	document.getElementById("bookName").innerHTML="<span style='color:rgb(238,232,170);'>فایل: </span>"+file.name.split('\\').pop()
		.replace(/(.txt)/,"").replace(/\./g,":");	// this writes the name of the file opened in the header at the top
}




//====================  SAVE TO A FILE (PERMANENT BACKUP)  =====================




function saveData(){
	if(myJSONData && document.getElementById("dataTable")){
		table=document.getElementById("dataTable");
		table_len=(table.rows.length);
		for(var i=0; i<table_len; i++){
			if(document.getElementById("save"+i)){	// so that there exists at least one unsaved row of data
				alert("لطفاً ابتدا ردیف ذخیره نشده را ذخیره بفرمایید!");
				return false;
			}
		}
		// if using  download.js
		download(  JSON.stringify(myJSONData),   "دفتر تلفن ("+persianDateTime().replace(/\:/g,".")+").txt" ,   "text/html");
	}else{
		alert("هنوز داده‌ای وارد نشده که ذخیره شود!");
	}
	document.getElementById("search").focus(); //
};





//=============  PREVENT LEAVING THE PAGE AS THERE MIGHT BE UNSAVED DATA ==============//



//$(window).bind('beforeunload', function(){
//	return 'شما در حال ترک نرم‌افزار هستید، آیا تمایل دارید یادداشت‌های خود را در صورت تغییر ذخیره نمایید؟';
//});	
window.onbeforeunload = function() {
	return "توصیه بر ذخیره‌ی داده‌ها پیش از حروج از نرم‌افزار است ... آیا اطمینان دارید می‌خواهید از نرم‌افزار خارج شوید؟!";
}	
//window.addEventListener("beforeunload", function(event) {
//	event.returnValue = "شما در حال ترک نرم‌افزار هستید، آیا تمایل دارید داده‌های خود را در صورت تغییر ذخیره نمایید؟";
	//saveFunctioin();
//});
